import React from 'react';
import { PortfolioMetrics } from '../types';
import { TrendingUp, TrendingDown, DollarSign, PieChart } from 'lucide-react';

interface DashboardProps {
  metrics: PortfolioMetrics;
}

export function Dashboard({ metrics }: DashboardProps) {
  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD'
    }).format(value);
  };

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
      <div className="bg-white rounded-lg shadow p-6">
        <div className="flex items-center justify-between">
          <div>
            <p className="text-sm text-gray-500">Total Portfolio Value</p>
            <p className="text-2xl font-bold">{formatCurrency(metrics.totalValue)}</p>
          </div>
          <DollarSign className="h-8 w-8 text-green-500" />
        </div>
      </div>

      <div className="bg-white rounded-lg shadow p-6">
        <div className="flex items-center justify-between">
          <div>
            <p className="text-sm text-gray-500">Total Investment</p>
            <p className="text-2xl font-bold">{formatCurrency(metrics.totalInvestment)}</p>
          </div>
          <PieChart className="h-8 w-8 text-blue-500" />
        </div>
      </div>

      <div className="bg-white rounded-lg shadow p-6">
        <div className="flex items-center justify-between">
          <div>
            <p className="text-sm text-gray-500">Total Gain/Loss</p>
            <p className={`text-2xl font-bold ${metrics.totalGainLoss >= 0 ? 'text-green-500' : 'text-red-500'}`}>
              {formatCurrency(metrics.totalGainLoss)}
            </p>
          </div>
          {metrics.totalGainLoss >= 0 ? (
            <TrendingUp className="h-8 w-8 text-green-500" />
          ) : (
            <TrendingDown className="h-8 w-8 text-red-500" />
          )}
        </div>
      </div>

      <div className="bg-white rounded-lg shadow p-6">
        <div>
          <p className="text-sm text-gray-500">Top Performer</p>
          {metrics.topPerformer ? (
            <>
              <p className="text-lg font-bold">{metrics.topPerformer.symbol}</p>
              <p className="text-sm text-green-500">
                {((metrics.topPerformer.currentPrice - metrics.topPerformer.purchasePrice) / 
                  metrics.topPerformer.purchasePrice * 100).toFixed(2)}%
              </p>
            </>
          ) : (
            <p className="text-lg">No stocks yet</p>
          )}
        </div>
      </div>
    </div>
  );
}