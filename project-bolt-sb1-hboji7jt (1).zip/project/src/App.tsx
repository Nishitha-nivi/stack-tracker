import React, { useState, useEffect } from 'react';
import { Stock, PortfolioMetrics } from './types';
import { Dashboard } from './components/Dashboard';
import { StockForm } from './components/StockForm';
import { StockList } from './components/StockList';
import { BarChart } from 'lucide-react';

function App() {
  const [stocks, setStocks] = useState<Stock[]>(() => {
    const saved = localStorage.getItem('portfolio');
    return saved ? JSON.parse(saved) : [];
  });

  const [metrics, setMetrics] = useState<PortfolioMetrics>({
    totalValue: 0,
    totalInvestment: 0,
    totalGainLoss: 0,
    topPerformer: null,
    worstPerformer: null
  });

  useEffect(() => {
    localStorage.setItem('portfolio', JSON.stringify(stocks));
    calculateMetrics();
  }, [stocks]);

  const calculateMetrics = () => {
    const totalValue = stocks.reduce((sum, stock) => sum + (stock.currentPrice * stock.shares), 0);
    const totalInvestment = stocks.reduce((sum, stock) => sum + (stock.purchasePrice * stock.shares), 0);
    
    const stocksWithReturns = stocks.map(stock => ({
      ...stock,
      return: ((stock.currentPrice - stock.purchasePrice) / stock.purchasePrice) * 100
    }));

    const topPerformer = stocksWithReturns.length > 0 
      ? stocksWithReturns.reduce((max, stock) => stock.return > max.return ? stock : max)
      : null;

    const worstPerformer = stocksWithReturns.length > 0
      ? stocksWithReturns.reduce((min, stock) => stock.return < min.return ? stock : min)
      : null;

    setMetrics({
      totalValue,
      totalInvestment,
      totalGainLoss: totalValue - totalInvestment,
      topPerformer,
      worstPerformer
    });
  };

  const addStock = (newStock: Omit<Stock, 'id' | 'currentPrice'>) => {
    // Simulate real-time price with a random variation of the purchase price
    const variation = (Math.random() - 0.5) * 10; // ±5% variation
    const currentPrice = newStock.purchasePrice * (1 + variation / 100);
    
    setStocks(prev => [...prev, {
      ...newStock,
      id: crypto.randomUUID(),
      currentPrice
    }]);
  };

  const deleteStock = (id: string) => {
    setStocks(prev => prev.filter(stock => stock.id !== id));
  };

  return (
    <div className="min-h-screen bg-gray-100">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="flex items-center justify-between mb-8">
          <div className="flex items-center">
            <BarChart className="h-8 w-8 text-blue-600 mr-3" />
            <h1 className="text-2xl font-bold text-gray-900">Portfolio Tracker</h1>
          </div>
        </div>
        
        <Dashboard metrics={metrics} />
        <StockForm onSubmit={addStock} />
        <StockList stocks={stocks} onDelete={deleteStock} />
      </div>
    </div>
  );
}

export default App;